import pandas as pd
import numpy as np
import random
import re

k='A1_03_05.xls'
l='A6_03_06.xls'
reg=re.match("^[a-zA-Z][1][_][0-9][0-9][_][0-9][0-9]",l)
reg2=re.match("^[a-zA-Z][2,3,4,5,6,7][_][0-9][0-9][_][0-9][0-9]",l)
if reg:
    print(l)
if reg2:
    print(l)