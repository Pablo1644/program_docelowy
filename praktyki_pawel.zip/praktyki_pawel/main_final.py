import pandas as pd
import math
from scipy import optimize
import matplotlib.pyplot as plt
import numpy as np
import pickle
import os
import re
from natsort import index_natsorted, order_by_index
# Baza danych z 1 folderu
pd.options.mode.chained_assignment = None

# Listy przechowywujace dane
list_of_height = []
list_of_mass = []
list_of_types = []
list_of_data = []
list_of_height2 = []
list_of_mass2 = []
list_of_types2 = []
list_of_data2 = []
# Funkcja odczytujaca wysokosc ze stringa,gdzie argumentem jest szukana wysokosc,zwracajaca wysokosc jako int (int minus int)

def get_height(needed_height):
    wanted_height = ''
    for ch in needed_height:
        if ch.isdigit():
            wanted_height += ch
    if wanted_height == '':
        return None
    if wanted_height.__len__()==2:
        a =int(wanted_height)
        return a
    if wanted_height[0] == '0':
        a = int(wanted_height[0])
        b = int(wanted_height[1:])
    else:
        b = int(wanted_height[2:])
        a = int(wanted_height[0:2])
    return b - a
# Funkcja zwracająca liste stringow z wysokosci
def get_height2(needed_height):
    if isinstance(needed_height,int):
        return None
    else:
        wanted_height=needed_height.split(' -- ')
        return wanted_height

def check_if_number_in_string(word):
    temp = True
    if isinstance(word,int):
        return False
    for element in word:
        if element.isspace():
            temp = False
            return temp
        else:
            temp = True
    return temp

def return_string(word):
    return int(word)

# Pierwsza DataFrame
df = pd.DataFrame()
df2 = pd.DataFrame()
source = r'C:\Users\spektrometr_DAP\Praktyki_Pawel\dane'
df=pd.read_pickle('data_1.pickle')
df.reset_index(inplace=True,drop=True)
df.dropna(subset=["Unnamed: 6"],axis=0,how='all',inplace=True)
df=df[df["Unnamed: 4"].str.contains("TOTAL")==False]
df= df[df['Unnamed: 6'] != 0]
df = df.reindex(index=order_by_index(df.index, index_natsorted(df['Unnamed: 3'], reverse=True)))
pd.set_option("display.max_rows", 12, "display.max_columns", None)
list_of_data = df.values.tolist()
dl = list_of_data.__len__()
#print(df.columns)

# Druga DataFrame
df2=pd.read_pickle('data_1.pickle')
df2.reset_index(inplace=True,drop=True)
df2.dropna(subset=["Unnamed: 6"],axis=0,how='all',inplace=True)
df2=df2[df2["Unnamed: 4"].str.contains("TOTAL")==False]
df2= df2[df2['Unnamed: 6'] != 0]
df2 = df2.reindex(index=order_by_index(df.index, index_natsorted(df2['Unnamed: 3'], reverse=True)))
pd.set_option("display.max_rows", 12, "display.max_columns", None)
list_of_data = df2.values.tolist()
dl = list_of_data2.__len__()




k = 0

df[['Hmin','Hmax']] = df['Unnamed: 1'].str.split('--',expand=True)
df.reset_index(inplace=True)
a=df['Unnamed: 1'].str.split('--',expand=True)[0]
#a=a.strip()
b=df['Unnamed: 1'].str.split('--',expand=True)[1]
df=df[df["Hmin"].str.contains("TOTAL")==False]
df = df.drop(df[df['Hmin']==' '].index)
df = df.drop(df[df['Hmin']=='32- - 46'].index)
df = df.drop(df[df['Hmax']==' '].index)
df=df.drop(columns=['Unnamed: 8','Unnamed: 0','Unnamed: 6','Unnamed: 7','Unnamed: 9','Unnamed: 2'])
df.insert(7,'H','')


df2[['Hmin','Hmax']] = df2['Unnamed: 1'].str.split('--',expand=True)
df2.reset_index(inplace=True)
a=df2['Unnamed: 1'].str.split('--',expand=True)[0]
#a=a.strip()
b=df2['Unnamed: 1'].str.split('--',expand=True)[1]
df2=df2[df2["Hmin"].str.contains("TOTAL")==False]
df2 = df2.drop(df2[df2['Hmin']==' '].index)
df2 = df2.drop(df2[df2['Hmin']=='32- - 46'].index)
df2 = df2.drop(df2[df2['Hmax']==' '].index)
df2=df2.drop(columns=['Unnamed: 8','Unnamed: 0','Unnamed: 6','Unnamed: 7','Unnamed: 9','Unnamed: 2'])
df2.insert(7,'Height','')


for index in df.index:
    try:
        df['Types'] = df['Unnamed: 3'] + ' ' + df['Unnamed: 4']
        p=int(df['Hmax'][index]) - int(df['Hmin'][index])
        df['H'][index]=p
    except ValueError :
        print(f'Index zly to {index}')
    except TypeError:
        print(f'zly index to{index}')

for index2 in df2.index:
   try:
       df2['Types']=df2['Unnamed: 3'] + ' ' + df2['Unnamed: 4']
       p = int(df2['Hmax'][index2]) - int(df2['Hmin'][index2])
       df2['Height'][index2]=p
       #print(p)
   except:
       print('ZLY INDEKS:'+index2)
       pass



df=df.drop(columns=['Unnamed: 3','Unnamed: 4','index'])
pd.set_option('display.max_rows', df.shape[0]+1)
df = df.reindex(index=order_by_index(df.index, index_natsorted(df['Types'], reverse=True)))
df['Types']=df['Types'].str.replace('-REN','')
df['Types']=df['Types'].str.replace('-RE','')
#

df2=df2.drop(columns=['Unnamed: 3','Unnamed: 4','index'])
pd.set_option('display.max_rows', df2.shape[0]+1)
df2 = df2.reindex(index=order_by_index(df2.index, index_natsorted(df2['Types'], reverse=True)))
df2['Types']=df2['Types'].str.replace('-REN','')
df2['Types']=df2['Types'].str.replace('-RE','')

df=df.reset_index(drop=True)
df2=df2.reset_index(drop=True)
print(df)
print('\n \n')
print(df2)
list_of_non_data=[]
for i in df.index:
    try:
        if df.index[i+1] in df.index:
            if df['Types'][i]==df['Types'][i]:
                list_of_non_data.append(df[i])
    except IndexError:
        pass

print(df[2])
print(list_of_non_data)

