import matplotlib.pylab as plt

my_dict = { 'Khan': 4, 'Khan': 2, 'Luna': 6, 'Mark': 11, 'Pooja': 8, 'Sara': 1}

myList = my_dict.items()
myList = sorted(myList)
x, y = zip(*myList)

plt.plot(x, y)
plt.xlabel('Key')
plt.ylabel('Value')
plt.title('My Dictionary')
plt.show()