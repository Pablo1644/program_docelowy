tekst ='ala--12'
for ch in tekst:
    if ch.isdigit():
        print(ch)